"""
Evaluation utilities: metrics computation, k-fold CV, and SHAP analysis.
"""

import numpy as np
from sklearn.model_selection import StratifiedKFold, cross_validate
from sklearn.metrics import (
    accuracy_score, matthews_corrcoef, confusion_matrix, make_scorer
)

from config import K_FOLDS, RANDOM_STATE


def compute_metrics(y_true, y_pred):
    """
    Compute accuracy, sensitivity, specificity, and MCC.
    Positive class = 0 (toxic).
    """
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[1, 0]).ravel()

    accuracy = accuracy_score(y_true, y_pred)
    sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
    mcc = matthews_corrcoef(y_true, y_pred)

    return {
        'Accuracy': round(accuracy, 4),
        'Sensitivity': round(sensitivity, 4),
        'Specificity': round(specificity, 4),
        'MCC': round(mcc, 4)
    }


def evaluate_classifier(clf, X_train, y_train, X_test, y_test,
                         clf_name, feature_name):
    """
    Train a sklearn classifier, evaluate on test set, run k-fold CV.

    Returns:
        dict with all metrics
    """
    # Train and predict on independent test set
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    test_metrics = compute_metrics(y_test, y_pred)

    # K-Fold Cross-Validation on training data
    scoring = {
        'accuracy': 'accuracy',
        'mcc': make_scorer(matthews_corrcoef)
    }
    cv = StratifiedKFold(n_splits=K_FOLDS, shuffle=True, random_state=RANDOM_STATE)
    cv_results = cross_validate(
        clf, X_train, y_train, cv=cv,
        scoring=scoring, return_train_score=False
    )

    cv_acc = np.mean(cv_results['test_accuracy'])
    cv_mcc = np.mean(cv_results['test_mcc'])

    result = {
        'Classifier': clf_name,
        'Feature_Group': feature_name,
        'Test_Accuracy': test_metrics['Accuracy'],
        'Test_Sensitivity': test_metrics['Sensitivity'],
        'Test_Specificity': test_metrics['Specificity'],
        'Test_MCC': test_metrics['MCC'],
        'CV_Accuracy_Mean': round(cv_acc, 4),
        'CV_MCC_Mean': round(cv_mcc, 4)
    }

    print(f"    {clf_name:20s} | Acc={test_metrics['Accuracy']:.4f} "
          f"| Sen={test_metrics['Sensitivity']:.4f} "
          f"| Spe={test_metrics['Specificity']:.4f} "
          f"| MCC={test_metrics['MCC']:.4f} "
          f"| CV_Acc={cv_acc:.4f}")

    return result


def run_shap_analysis(clf, X_train, X_test, feature_names, clf_name,
                       feature_group, output_dir):
    """
    Run SHAP on a trained classifier and save a summary plot.
    Silently skips if shap isn't installed.
    """
    try:
        import shap
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        import os

        print(f"  Running SHAP for {clf_name} on {feature_group}...")

        X_bg = X_train[:min(100, len(X_train))]
        X_explain = X_test[:min(50, len(X_test))]

        if hasattr(clf, 'predict_proba'):
            explainer = shap.KernelExplainer(clf.predict_proba, X_bg)
        else:
            explainer = shap.KernelExplainer(clf.predict, X_bg)

        shap_values = explainer.shap_values(X_explain)

        plt.figure(figsize=(10, 8))
        if isinstance(shap_values, list):
            shap.summary_plot(shap_values[1], X_explain,
                              feature_names=feature_names,
                              max_display=20, show=False)
        else:
            shap.summary_plot(shap_values, X_explain,
                              feature_names=feature_names,
                              max_display=20, show=False)

        plt.title(f'SHAP Feature Importance: {clf_name} ({feature_group})')
        plt.tight_layout()
        fname = f'shap_{clf_name}_{feature_group}.png'
        plt.savefig(os.path.join(output_dir, fname), dpi=150, bbox_inches='tight')
        plt.close()
        print(f"  Saved: {output_dir}/{fname}")

    except ImportError:
        print("  SHAP not installed. Skipping. Install with: pip install shap")
    except Exception as e:
        print(f"  SHAP analysis failed: {e}")
