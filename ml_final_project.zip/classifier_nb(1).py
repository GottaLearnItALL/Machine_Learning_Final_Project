"""
Gaussian Naive Bayes classifier for peptide toxicity prediction.

Naive Bayes assumes features are conditionally independent given the
class label. GaussianNB assumes each feature follows a normal distribution.
Fast to train and works as a good baseline.
"""

from sklearn.naive_bayes import GaussianNB


NAME = "Naive_Bayes"


def get_model():
    """Return a configured Gaussian Naive Bayes classifier."""
    return GaussianNB()
