"""
Artificial Neural Network (MLP) classifier for peptide toxicity prediction.

Uses sklearn's MLPClassifier — a multi-layer perceptron with two hidden
layers (128, 64 neurons). Includes early stopping to prevent overfitting.
"""

from sklearn.neural_network import MLPClassifier
from config import RANDOM_STATE


NAME = "ANN_MLP"


def get_model():
    """Return a configured ANN/MLP classifier."""
    return MLPClassifier(
        hidden_layer_sizes=(128, 64),
        activation='relu',
        solver='adam',
        max_iter=500,
        random_state=RANDOM_STATE,
        early_stopping=True,
        validation_fraction=0.1
    )
