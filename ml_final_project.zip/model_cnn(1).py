"""
1D Convolutional Neural Network for peptide toxicity prediction.

Architecture:
  Input → Conv1D(32) → ReLU → BN → MaxPool
        → Conv1D(64) → ReLU → BN → MaxPool
        → Conv1D(128) → ReLU → BN → GlobalAvgPool
        → Dense(64) → ReLU → Dropout → Dense(2)

Uses CUDA automatically when available.
"""

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset

from config import EPOCHS_CNN, BATCH_SIZE, LEARNING_RATE
from evaluation import compute_metrics


class PeptideCNN(nn.Module):
    """1D CNN that takes a flat feature vector as input."""

    def __init__(self, input_dim, num_classes=2):
        super(PeptideCNN, self).__init__()

        self.conv_layers = nn.Sequential(
            nn.Conv1d(in_channels=1, out_channels=32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.BatchNorm1d(32),
            nn.MaxPool1d(kernel_size=2),

            nn.Conv1d(in_channels=32, out_channels=64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.BatchNorm1d(64),
            nn.MaxPool1d(kernel_size=2),

            nn.Conv1d(in_channels=64, out_channels=128, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.BatchNorm1d(128),
            nn.AdaptiveAvgPool1d(1)  # Global average pooling
        )

        self.classifier = nn.Sequential(
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(64, num_classes)
        )

    def forward(self, x):
        # (batch, features) → (batch, 1, features) for Conv1d
        x = x.unsqueeze(1)
        x = self.conv_layers(x)
        x = x.squeeze(-1)
        x = self.classifier(x)
        return x


def train_and_evaluate(X_train, y_train, X_test, y_test, feature_name):
    """
    Train a CNN and evaluate on the test set.

    Args:
        X_train, y_train: scaled training features and labels (numpy)
        X_test, y_test: scaled test features and labels (numpy)
        feature_name: name of the feature group (for logging)

    Returns:
        dict with result metrics
    """
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"    CNN device: {device}")

    # Convert to tensors
    X_tr = torch.FloatTensor(X_train).to(device)
    y_tr = torch.LongTensor(y_train).to(device)
    X_te = torch.FloatTensor(X_test).to(device)

    train_dataset = TensorDataset(X_tr, y_tr)
    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)

    # Build model
    model = PeptideCNN(input_dim=X_train.shape[1]).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, patience=5, factor=0.5)

    # Train
    model.train()
    for epoch in range(EPOCHS_CNN):
        epoch_loss = 0
        for batch_X, batch_y in train_loader:
            optimizer.zero_grad()
            outputs = model(batch_X)
            loss = criterion(outputs, batch_y)
            loss.backward()
            optimizer.step()
            epoch_loss += loss.item()

        scheduler.step(epoch_loss)

        if (epoch + 1) % 10 == 0:
            avg_loss = epoch_loss / len(train_loader)
            print(f"      Epoch {epoch+1}/{EPOCHS_CNN} | Loss: {avg_loss:.4f}")

    # Evaluate
    model.eval()
    with torch.no_grad():
        outputs = model(X_te)
        _, y_pred = torch.max(outputs, 1)
        y_pred = y_pred.cpu().numpy()

    metrics = compute_metrics(y_test, y_pred)

    result = {
        'Classifier': 'CNN',
        'Feature_Group': feature_name,
        'Test_Accuracy': metrics['Accuracy'],
        'Test_Sensitivity': metrics['Sensitivity'],
        'Test_Specificity': metrics['Specificity'],
        'Test_MCC': metrics['MCC'],
        'CV_Accuracy_Mean': '-',
        'CV_MCC_Mean': '-'
    }

    print(f"    {'CNN':20s} | Acc={metrics['Accuracy']:.4f} "
          f"| Sen={metrics['Sensitivity']:.4f} "
          f"| Spe={metrics['Specificity']:.4f} "
          f"| MCC={metrics['MCC']:.4f}")

    return result, model
