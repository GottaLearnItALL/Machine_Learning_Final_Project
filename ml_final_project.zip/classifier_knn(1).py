"""
K-Nearest Neighbors classifier for peptide toxicity prediction.

KNN classifies a sample based on the majority vote of its k nearest
neighbors in feature space. We use Euclidean distance by default.
"""

from sklearn.neighbors import KNeighborsClassifier
from config import RANDOM_STATE


NAME = "KNN"


def get_model():
    """Return a configured KNN classifier."""
    return KNeighborsClassifier(
        n_neighbors=5,
        weights='uniform',
        metric='euclidean',
        n_jobs=-1
    )
