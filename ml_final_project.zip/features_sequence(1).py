"""
Sequence-based feature extraction for peptide sequences.

These features treat the peptide purely as a string of letters,
without considering physicochemical properties.

Features extracted:
  - Amino Acid Composition (AAC): frequency of each of 20 amino acids (20 features)
  - Dipeptide Composition (DPC): frequency of each pair of consecutive AAs (400 features)

Total: 420 features

References: Ferdous et al. 2024, Muhammod et al. 2019, Chen et al. 2018
"""

import pandas as pd
from collections import Counter


# Standard 20 amino acids
AMINO_ACIDS = list('ACDEFGHIKLMNPQRSTVWY')


def extract(sequences):
    """
    Extract sequence-based features (AAC + DPC) from peptide sequences.

    Args:
        sequences: list of peptide strings

    Returns:
        pd.DataFrame with 420 feature columns (20 AAC + 400 DPC)
    """
    all_features = []

    for seq in sequences:
        feats = {}
        seq_len = len(seq)

        # ---- Amino Acid Composition (AAC) ----
        # Fraction of each amino acid in the sequence
        aa_counts = Counter(seq)
        for aa in AMINO_ACIDS:
            feats[f'AAC_{aa}'] = aa_counts.get(aa, 0) / max(seq_len, 1)

        # ---- Dipeptide Composition (DPC) ----
        # Fraction of each consecutive amino acid pair
        dipeptides = [seq[i:i+2] for i in range(len(seq) - 1)]
        dp_counts = Counter(dipeptides)
        num_dp = max(len(dipeptides), 1)

        for aa1 in AMINO_ACIDS:
            for aa2 in AMINO_ACIDS:
                dp = aa1 + aa2
                feats[f'DPC_{dp}'] = dp_counts.get(dp, 0) / num_dp

        all_features.append(feats)

    df = pd.DataFrame(all_features)
    print(f"  Sequence features: {df.shape[1]} features (20 AAC + 400 DPC)")
    return df
