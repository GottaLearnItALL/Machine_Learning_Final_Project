#!/bin/bash
# ==============================================================================
# SETUP SCRIPT — run this once to install all dependencies
# ==============================================================================
# Usage:  chmod +x setup.sh && ./setup.sh
# ==============================================================================

set -e

echo "=========================================="
echo "  Peptide Toxicity Prediction — Setup"
echo "=========================================="

# Check if uv is installed
if ! command -v uv &> /dev/null; then
    echo "[1/4] Installing uv..."
    curl -LsSf https://astral.sh/uv/install.sh | sh
    export PATH="$HOME/.local/bin:$PATH"
else
    echo "[1/4] uv already installed ✓"
fi

# Create virtual environment
echo "[2/4] Creating virtual environment..."
uv venv .venv
source .venv/bin/activate

# Install base dependencies from pyproject.toml
echo "[3/4] Installing base dependencies..."
uv pip install ".[plm]"

# Install PyTorch with CUDA 12.1 support
# Change cu121 to cu118 if you have CUDA 11.8, or to cpu if no GPU
echo "[4/4] Installing PyTorch with CUDA 12.1..."
uv pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121

echo ""
echo "=========================================="
echo "  Setup complete!"
echo "=========================================="
echo ""
echo "To activate the environment:"
echo "  source .venv/bin/activate"
echo ""
echo "To run the pipeline:"
echo "  python main.py"
echo ""
echo "If you DON'T have a CUDA GPU, re-run torch install with:"
echo "  uv pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu"
echo ""
