"""
Support Vector Machine classifier for peptide toxicity prediction.

SVM finds the optimal hyperplane that separates classes with maximum
margin. We use the RBF kernel which works well for non-linear problems.
"""

from sklearn.svm import SVC
from config import RANDOM_STATE


NAME = "SVM"


def get_model():
    """Return a configured SVM classifier."""
    return SVC(
        kernel='rbf',
        C=1.0,
        gamma='scale',
        random_state=RANDOM_STATE
    )
