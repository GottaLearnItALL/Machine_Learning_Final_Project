"""
Protein Language Model (PLM) embedding extraction.

Uses Facebook's ESM-2 model to generate learned numerical representations
of peptide sequences. ESM-2 is a transformer trained on millions of
protein sequences from UniRef.

If ESM-2 / transformers library isn't available, falls back to
k-mer frequency features as a reasonable substitute.

Reference: Lin et al. 2023 — "Evolutionary-scale prediction of
atomic-level protein structure with a language model"
"""

import numpy as np
import pandas as pd
from collections import Counter
import torch

from config import PLM_MODEL_NAME


def extract(sequences, model_name=None):
    """
    Extract PLM embeddings for peptide sequences.
    Tries ESM-2 first, falls back to k-mer features.

    Args:
        sequences: list of peptide strings
        model_name: HuggingFace model name (default from config)

    Returns:
        pd.DataFrame with embedding features
    """
    if model_name is None:
        model_name = PLM_MODEL_NAME

    try:
        return _extract_esm2(sequences, model_name)
    except (ImportError, OSError, Exception) as e:
        print(f"  ESM-2 not available ({e}).")
        print(f"  Using fallback: k-mer frequency encoding.")
        return _extract_kmer(sequences)


def _extract_esm2(sequences, model_name):
    """
    Extract embeddings using ESM-2 via HuggingFace transformers.
    Uses mean pooling over residue embeddings.
    """
    from transformers import AutoTokenizer, AutoModel

    print(f"  Loading PLM: {model_name}...")
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModel.from_pretrained(model_name)
    model.eval()

    # Use CUDA if available
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = model.to(device)
    print(f"  PLM running on: {device}")

    embeddings = []
    with torch.no_grad():
        for i, seq in enumerate(sequences):
            inputs = tokenizer(seq, return_tensors="pt",
                               padding=True, truncation=True, max_length=512)
            inputs = {k: v.to(device) for k, v in inputs.items()}

            outputs = model(**inputs)
            # Mean pool over residue positions (skip special tokens)
            emb = outputs.last_hidden_state[0, 1:-1, :].mean(dim=0).cpu().numpy()
            embeddings.append(emb)

            if (i + 1) % 100 == 0:
                print(f"    Processed {i+1}/{len(sequences)} sequences...")

    emb_array = np.array(embeddings)
    columns = [f'PLM_{j}' for j in range(emb_array.shape[1])]
    df = pd.DataFrame(emb_array, columns=columns)
    print(f"  PLM features: {df.shape[1]} dimensions from ESM-2")
    return df


def _extract_kmer(sequences, k_values=(1, 2, 3)):
    """
    Fallback: k-mer frequency features (k=1,2,3).
    Captures similar positional/compositional info as PLMs
    but without the learned contextual representations.
    """
    all_features = []

    for seq in sequences:
        feats = {}
        for k in k_values:
            kmers = [seq[i:i+k] for i in range(len(seq) - k + 1)]
            kmer_counts = Counter(kmers)
            total = max(len(kmers), 1)
            for kmer, count in kmer_counts.items():
                feats[f'kmer{k}_{kmer}'] = count / total
        all_features.append(feats)

    df = pd.DataFrame(all_features).fillna(0)
    print(f"  K-mer features (PLM fallback): {df.shape[1]} features")
    return df
