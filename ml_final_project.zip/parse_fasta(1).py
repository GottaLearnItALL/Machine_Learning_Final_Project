"""
FASTA file parser for the peptide toxicity dataset.

Each record in the FASTA file looks like:
    >peptide|1
    EITVEPVRHPKKDPSEAE

The number after '|' is the label (0 = toxic, 1 = non-toxic).
The next line is the peptide amino acid sequence.
"""

import numpy as np
import pandas as pd
import os


VALID_AMINO_ACIDS = set('ACDEFGHIKLMNPQRSTVWY')


def parse_fasta(filepath):
    """
    Parse a FASTA file and return a DataFrame with columns: sequence, label.
    Skips sequences containing invalid amino acid characters.
    """
    sequences = []
    labels = []

    with open(filepath, 'r') as f:
        lines = f.readlines()

    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line.startswith('>'):
            # Header line: >peptide|LABEL
            parts = line.split('|')
            if len(parts) >= 2:
                label = int(parts[-1].strip())
            else:
                i += 1
                continue

            # Next line is the sequence
            i += 1
            if i < len(lines):
                seq = lines[i].strip().upper()
                if all(c in VALID_AMINO_ACIDS for c in seq) and len(seq) > 0:
                    sequences.append(seq)
                    labels.append(label)
        i += 1

    df = pd.DataFrame({'sequence': sequences, 'label': labels})
    print(f"  Parsed {filepath}: {len(df)} sequences "
          f"(toxic={sum(df['label']==0)}, non-toxic={sum(df['label']==1)})")
    return df


def generate_synthetic_data(n_train=500, n_test=100, seed=42):
    """
    Generate random synthetic peptide data for testing the pipeline
    when real FASTA files aren't available.
    """
    np.random.seed(seed)
    amino_acids = list('ACDEFGHIKLMNPQRSTVWY')

    def random_peptide(min_len=10, max_len=40):
        length = np.random.randint(min_len, max_len)
        return ''.join(np.random.choice(amino_acids, size=length))

    train_seqs = [random_peptide() for _ in range(n_train)]
    test_seqs = [random_peptide() for _ in range(n_test)]
    train_labels = np.random.randint(0, 2, n_train)
    test_labels = np.random.randint(0, 2, n_test)

    train_df = pd.DataFrame({'sequence': train_seqs, 'label': train_labels})
    test_df = pd.DataFrame({'sequence': test_seqs, 'label': test_labels})

    print(f"  Generated {n_train} training + {n_test} test synthetic sequences.")
    return train_df, test_df


def load_data(train_path, test_path):
    """
    Load data from FASTA files, or fall back to synthetic data.
    Returns (train_df, test_df) DataFrames.
    """
    if os.path.exists(train_path) and os.path.exists(test_path):
        train_df = parse_fasta(train_path)
        test_df = parse_fasta(test_path)
    else:
        print(f"  WARNING: {train_path} and/or {test_path} not found.")
        print(f"  Current directory: {os.getcwd()}")
        print(f"  Generating synthetic data for demonstration...\n")
        train_df, test_df = generate_synthetic_data()

    return train_df, test_df
