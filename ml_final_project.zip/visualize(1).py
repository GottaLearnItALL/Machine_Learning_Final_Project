"""
Visualization utilities — generates all plots for the report.
Publication-quality figures with consistent styling.
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
from matplotlib.gridspec import GridSpec

from config import OUTPUT_DIR

#  GLOBAL STYLE

PALETTE = {
    'Physicochemical': '#2C7BB6',
    'Sequence-Based':  '#1A9641',
    'PLM':             '#D7191C',
    'Combined':        '#7B2D8B',
}
FALLBACK_COLORS = list(PALETTE.values())

FONT_TITLE  = {'fontsize': 13, 'fontweight': 'bold', 'color': '#1a1a2e'}
FONT_LABEL  = {'fontsize': 11, 'color': '#333333'}
FONT_TICK   = {'labelsize': 10}
FONT_ANNOT  = {'fontsize': 9,  'color': '#111111', 'fontweight': 'bold'}

def _apply_base_style():
    plt.rcParams.update({
        'figure.facecolor':  'white',
        'axes.facecolor':    '#f9f9f9',
        'axes.edgecolor':    '#cccccc',
        'axes.linewidth':    0.8,
        'axes.spines.top':   False,
        'axes.spines.right': False,
        'grid.color':        '#e0e0e0',
        'grid.linewidth':    0.6,
        'axes.grid':         True,
        'axes.grid.axis':    'y',
        'font.family':       'DejaVu Sans',
        'xtick.direction':   'out',
        'ytick.direction':   'out',
    })

def _save(fig, filename):
    path = os.path.join(OUTPUT_DIR, filename)
    fig.savefig(path, dpi=200, bbox_inches='tight', facecolor='white')
    plt.close(fig)
    print(f"  Saved: {path}")


#  1. CLASSIFIER COMPARISON  (Accuracy + MCC)

def plot_classifier_comparison(results_df):
    """
    Two separate figures (one per metric) — one classifier group per figure,
    tall enough so bar labels never collide.
    """
    _apply_base_style()

    numeric = results_df[results_df['CV_Accuracy_Mean'] != '-'].copy()
    if numeric.empty:
        return

    for col in ('Test_Accuracy', 'Test_MCC'):
        numeric[col] = pd.to_numeric(numeric[col], errors='coerce')

    feature_groups = numeric['Feature_Group'].unique().tolist()
    colors = [PALETTE.get(fg, FALLBACK_COLORS[i % len(FALLBACK_COLORS)])
              for i, fg in enumerate(feature_groups)]

    for metric, title, fname, ylim in [
        ('Test_Accuracy', 'Test Accuracy by Classifier & Feature Group',
         'classifier_accuracy.png', (0.5, 1.12)),
        ('Test_MCC',      'Test MCC by Classifier & Feature Group',
         'classifier_mcc.png',      (0.0, 1.05)),
    ]:
        pivot = numeric.pivot_table(
            values=metric, index='Classifier',
            columns='Feature_Group', aggfunc='first'
        )
        classifiers = pivot.index.tolist()
        n_clf  = len(classifiers)
        n_bars = len(feature_groups)
        x      = np.arange(n_clf)
        width  = 0.70 / n_bars

        # Wide + tall so labels have room
        fig, ax = plt.subplots(figsize=(max(14, n_clf * 3.0), 7))
        fig.suptitle(title, fontsize=14, fontweight='bold',
                     color='#1a1a2e', y=1.01)

        for i, (fg, color) in enumerate(zip(feature_groups, colors)):
            if fg not in pivot.columns:
                continue
            vals   = pivot[fg].values.astype(float)
            offset = (i - n_bars / 2 + 0.5) * width
            bars   = ax.bar(x + offset, vals, width * 0.85,
                            label=fg, color=color, alpha=0.88,
                            edgecolor='white', linewidth=0.5, zorder=3)
            # Label only on top of each bar — no rotation, font small enough
            for bar, v in zip(bars, vals):
                if not np.isnan(v):
                    ax.text(
                        bar.get_x() + bar.get_width() / 2,
                        bar.get_height() + 0.006,
                        f'{v:.2f}',
                        ha='center', va='bottom',
                        fontsize=7, fontweight='bold', color='#222222',
                    )

        ax.set_xticks(x)
        ax.set_xticklabels(classifiers, rotation=25, ha='right', fontsize=11)
        ax.tick_params(axis='y', labelsize=10)
        ax.set_ylabel(title.split(' by')[0], **FONT_LABEL)
        ax.set_ylim(*ylim)
        ax.axhline(0, color='#bbbbbb', linewidth=0.7, zorder=1)

        handles = [mpatches.Patch(color=c, label=fg)
                   for fg, c in zip(feature_groups, colors)]
        ax.legend(handles=handles, title='Feature Group',
                  loc='lower right', fontsize=9,
                  frameon=True, framealpha=0.9)

        plt.tight_layout()
        _save(fig, fname)


#  3. ATTENTION WEIGHTS

def plot_attention_weights(attn_weights):
    """Mean attention bar chart + per-sample distribution violin plot."""
    _apply_base_style()

    view_names = ['Physicochemical', 'Sequence-Based', 'PLM']
    colors     = [PALETTE[v] for v in view_names]
    mean_attn  = attn_weights.mean(axis=0)

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    fig.suptitle('Attention Fusion Network — Feature View Weights',
                 fontsize=14, fontweight='bold', color='#1a1a2e', y=1.02)

    # — Bar chart (mean weights) —
    bars = axes[0].bar(view_names, mean_attn, color=colors,
                       alpha=0.88, edgecolor='white', linewidth=0.6,
                       width=0.5, zorder=3)
    for bar, v in zip(bars, mean_attn):
        axes[0].text(bar.get_x() + bar.get_width() / 2,
                     v + 0.012, f'{v:.3f}',
                     ha='center', va='bottom', **FONT_ANNOT)
    axes[0].set_title('Mean Attention Weight per Feature View', **FONT_TITLE, pad=10)
    axes[0].set_ylabel('Mean Attention Weight', **FONT_LABEL)
    axes[0].set_ylim(0, min(1.15, mean_attn.max() * 1.35))
    axes[0].tick_params(axis='both', labelsize=10)

    #box plot (distribution) —
    data_by_view = [attn_weights[:, i] for i in range(len(view_names))]
    vp = axes[1].violinplot(data_by_view, positions=range(len(view_names)),
                             showmedians=True, showextrema=True)
    for i, (body, color) in enumerate(zip(vp['bodies'], colors)):
        body.set_facecolor(color)
        body.set_alpha(0.7)
    vp['cmedians'].set_color('#111111')
    vp['cmedians'].set_linewidth(1.5)

    axes[1].set_xticks(range(len(view_names)))
    axes[1].set_xticklabels(view_names, fontsize=10)
    axes[1].tick_params(axis='y', labelsize=10)
    axes[1].set_title('Attention Weight Distribution per Feature View', **FONT_TITLE, pad=10)
    axes[1].set_ylabel('Attention Weight', **FONT_LABEL)

    plt.tight_layout()
    _save(fig, 'attention_weights.png')


#  4. FEATURE GROUP COMPARISON

def plot_feature_group_comparison(results_df):
    """Mean accuracy per feature group with individual classifier dots overlaid."""
    _apply_base_style()

    numeric = results_df[results_df['CV_Accuracy_Mean'] != '-'].copy()
    if numeric.empty:
        return
    numeric['Test_Accuracy'] = pd.to_numeric(numeric['Test_Accuracy'], errors='coerce')

    group_means = numeric.groupby('Feature_Group')['Test_Accuracy'].mean()
    groups      = group_means.index.tolist()
    colors      = [PALETTE.get(g, FALLBACK_COLORS[i % len(FALLBACK_COLORS)])
                   for i, g in enumerate(groups)]

    fig, ax = plt.subplots(figsize=(9, 5))
    fig.suptitle('Mean Test Accuracy by Feature Group',
                 fontsize=14, fontweight='bold', color='#1a1a2e')

    bars = ax.bar(groups, group_means.values, color=colors,
                  alpha=0.88, edgecolor='white', linewidth=0.6,
                  width=0.5, zorder=3)

    for bar, v in zip(bars, group_means.values):
        ax.text(bar.get_x() + bar.get_width() / 2,
                v + 0.01, f'{v:.3f}',
                ha='center', va='bottom', **FONT_ANNOT)

    ax.set_ylabel('Mean Test Accuracy', **FONT_LABEL)
    ax.set_ylim(0, 1.1)
    ax.tick_params(axis='x', labelsize=12)
    ax.tick_params(axis='y', labelsize=10)

    plt.tight_layout()
    _save(fig, 'feature_group_comparison.png')


#  ENTRY POINT

def generate_all_plots(results_df, attn_weights=None):
    """Run all visualizations. Classifier comparison saves two files:
    classifier_accuracy.png and classifier_mcc.png"""
    print("\n[VISUALIZATIONS]")
    plot_classifier_comparison(results_df)
    plot_feature_group_comparison(results_df)
    if attn_weights is not None:
        plot_attention_weights(attn_weights)