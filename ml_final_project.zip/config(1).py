"""
Shared configuration for the entire pipeline.
Edit paths and hyperparameters here.
"""

import os

# --- File paths ---
TRAIN_FILE = "Train.fasta"
TEST_FILE = "test.fasta"
OUTPUT_DIR = "results"

# --- ML settings ---
K_FOLDS = 5
RANDOM_STATE = 42

# --- Deep learning settings ---
EPOCHS_CNN = 50
EPOCHS_FUSION = 50
BATCH_SIZE = 32
LEARNING_RATE = 0.001

# --- PLM settings ---
PLM_MODEL_NAME = "facebook/esm2_t6_8M_UR50D"  # smallest ESM-2, fast

# Create output directory
os.makedirs(OUTPUT_DIR, exist_ok=True)
