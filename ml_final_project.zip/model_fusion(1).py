"""
Multi-View Attention Fusion Network (bonus architecture).

Instead of concatenating all feature groups, this model:
  1. Encodes each feature view through its own dense network
  2. Learns attention weights that decide how much to trust each view
  3. Fuses the weighted views into a single representation
  4. Classifies from the fused representation

This lets the model dynamically weight physicochemical vs sequence-based
vs PLM features for each individual peptide.
"""

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim

from config import EPOCHS_FUSION, BATCH_SIZE, LEARNING_RATE
from evaluation import compute_metrics


VIEW_NAMES = ['Physicochemical', 'Sequence-Based', 'PLM']


class MultiViewAttentionFusion(nn.Module):
    """
    Attention-based fusion of multiple feature views.
    Each view gets its own encoder, then a shared attention layer
    learns how to combine them.
    """

    def __init__(self, view_dims, hidden_dim=64, num_classes=2):
        super(MultiViewAttentionFusion, self).__init__()
        self.num_views = len(view_dims)

        # Separate encoder per view
        self.view_encoders = nn.ModuleList([
            nn.Sequential(
                nn.Linear(dim, hidden_dim),
                nn.ReLU(),
                nn.BatchNorm1d(hidden_dim),
                nn.Dropout(0.2)
            )
            for dim in view_dims
        ])

        # Attention: takes concatenated encoded views → produces weights
        self.attention = nn.Sequential(
            nn.Linear(hidden_dim * self.num_views, self.num_views),
            nn.Softmax(dim=1)
        )

        # Final classifier on fused representation
        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim, 32),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(32, num_classes)
        )

    def forward(self, views, return_attention=False):
        # Encode each view independently
        encoded = [enc(view) for enc, view in zip(self.view_encoders, views)]

        # Compute attention weights over views
        concat = torch.cat(encoded, dim=1)
        attn_weights = self.attention(concat)  # (batch, num_views)

        # Weighted sum of encoded views
        stacked = torch.stack(encoded, dim=1)       # (batch, num_views, hidden)
        attn_expanded = attn_weights.unsqueeze(2)    # (batch, num_views, 1)
        fused = (stacked * attn_expanded).sum(dim=1) # (batch, hidden)

        output = self.classifier(fused)

        if return_attention:
            return output, attn_weights
        return output


def train_and_evaluate(views_train, views_test, y_train, y_test):
    """
    Train the fusion model and evaluate.

    Args:
        views_train: list of 3 numpy arrays (one per feature group, training)
        views_test: list of 3 numpy arrays (one per feature group, test)
        y_train, y_test: label arrays

    Returns:
        (result_dict, model, attention_weights_array)
    """
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"    Fusion device: {device}")

    # Convert to tensors
    vt_train = [torch.FloatTensor(v).to(device) for v in views_train]
    vt_test = [torch.FloatTensor(v).to(device) for v in views_test]
    y_tr = torch.LongTensor(y_train).to(device)

    view_dims = [v.shape[1] for v in views_train]
    n_train = len(y_train)

    model = MultiViewAttentionFusion(view_dims).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)

    # Training
    model.train()
    for epoch in range(EPOCHS_FUSION):
        perm = torch.randperm(n_train)
        epoch_loss = 0
        n_batches = 0

        for start in range(0, n_train, BATCH_SIZE):
            end = min(start + BATCH_SIZE, n_train)
            idx = perm[start:end]

            batch_views = [v[idx] for v in vt_train]
            batch_y = y_tr[idx]

            optimizer.zero_grad()
            outputs = model(batch_views)
            loss = criterion(outputs, batch_y)
            loss.backward()
            optimizer.step()

            epoch_loss += loss.item()
            n_batches += 1

        if (epoch + 1) % 10 == 0:
            print(f"      Epoch {epoch+1}/{EPOCHS_FUSION} "
                  f"| Loss: {epoch_loss/n_batches:.4f}")

    # Evaluate
    model.eval()
    with torch.no_grad():
        outputs, attn_weights = model(vt_test, return_attention=True)
        _, y_pred = torch.max(outputs, 1)
        y_pred = y_pred.cpu().numpy()
        attn_weights = attn_weights.cpu().numpy()

    metrics = compute_metrics(y_test, y_pred)

    result = {
        'Classifier': 'Attention_Fusion',
        'Feature_Group': 'All_Combined',
        'Test_Accuracy': metrics['Accuracy'],
        'Test_Sensitivity': metrics['Sensitivity'],
        'Test_Specificity': metrics['Specificity'],
        'Test_MCC': metrics['MCC'],
        'CV_Accuracy_Mean': '-',
        'CV_MCC_Mean': '-'
    }

    # Print attention weight analysis
    mean_attn = attn_weights.mean(axis=0)
    print(f"\n  Attention Fusion Results:")
    print(f"    Acc={metrics['Accuracy']:.4f} | Sen={metrics['Sensitivity']:.4f} "
          f"| Spe={metrics['Specificity']:.4f} | MCC={metrics['MCC']:.4f}")
    print(f"  Average Attention Weights:")
    for name, weight in zip(VIEW_NAMES, mean_attn):
        print(f"    {name}: {weight:.4f} ({weight*100:.1f}%)")

    return result, model, attn_weights
