"""
Bagging classifier for peptide toxicity prediction.

Bagging (Bootstrap Aggregating) trains multiple base estimators on
random subsets of the data and aggregates predictions. Reduces variance
and helps prevent overfitting.
"""

from sklearn.ensemble import BaggingClassifier
from config import RANDOM_STATE


NAME = "Bagging"


def get_model():
    """Return a configured Bagging classifier."""
    return BaggingClassifier(
        n_estimators=50,
        max_samples=0.8,
        max_features=1.0,
        random_state=RANDOM_STATE,
        n_jobs=-1
    )
