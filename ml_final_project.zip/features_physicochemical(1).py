# sources: course-provided attribute table, ferdous et al. 2024,
# muhammod et al. 2019, chen et al. 2018

import numpy as np
import pandas as pd

# amino acid order matching the provided excel file
AA_ORDER = list('ACDEFGHIKLMNPQRSTVWY')

# all 28 physicochemical properties from the professor's excel file.
# each entry maps property name -> list of values in AA_ORDER.
AA_PROPERTIES = {
    'structure_derived_hydrophobicity': {
        'A': 0.5, 'C': 2.3, 'D': -1, 'E': -0.9, 'F': 1.3,
        'G': 0.3, 'H': 0.8, 'I': 1.8, 'K': -1.2, 'L': 0.9,
        'M': 0.8, 'N': -0.1, 'P': -0.6, 'Q': -0.7, 'R': -0.3,
        'S': -0.4, 'T': -0.1, 'V': 1, 'W': 1.9, 'Y': 0.9
    },
    'polarizability': {
        'A': 0.046, 'C': 0.128, 'D': 0.105, 'E': 0.151, 'F': 0.29,
        'G': 0, 'H': 0.23, 'I': 0.186, 'K': 0.219, 'L': 0.186,
        'M': 0.221, 'N': 0.134, 'P': 0.131, 'Q': 0.18, 'R': 0.291,
        'S': 0.062, 'T': 0.108, 'V': 0.14, 'W': 0.409, 'Y': 0.298
    },
    'normalized_freq_alpha_helix': {
        'A': 1.42, 'C': 0.7, 'D': 1.01, 'E': 1.51, 'F': 1.13,
        'G': 0.57, 'H': 1, 'I': 1.08, 'K': 1.16, 'L': 1.21,
        'M': 1.45, 'N': 0.67, 'P': 0.57, 'Q': 1.11, 'R': 0.98,
        'S': 0.77, 'T': 0.83, 'V': 1.06, 'W': 1.08, 'Y': 0.69
    },
    'normalized_freq_beta_strand': {
        'A': 0.83, 'C': 1.19, 'D': 0.54, 'E': 0.37, 'F': 1.38,
        'G': 0.75, 'H': 0.87, 'I': 1.6, 'K': 0.74, 'L': 1.3,
        'M': 1.05, 'N': 0.89, 'P': 0.55, 'Q': 1.1, 'R': 0.93,
        'S': 0.75, 'T': 1.19, 'V': 1.7, 'W': 1.37, 'Y': 1.47
    },
    'normalized_freq_turn': {
        'A': 0.66, 'C': 1.19, 'D': 1.46, 'E': 0.74, 'F': 0.6,
        'G': 1.56, 'H': 0.95, 'I': 0.47, 'K': 1.01, 'L': 0.59,
        'M': 0.6, 'N': 1.56, 'P': 1.52, 'Q': 0.98, 'R': 0.95,
        'S': 1.43, 'T': 0.96, 'V': 0.5, 'W': 0.96, 'Y': 1.14
    },
    'hydrophobicity_hplc_ph7_5': {
        'A': 0.35, 'C': 0.76, 'D': -2.15, 'E': -1.95, 'F': 1.69,
        'G': 0, 'H': -0.65, 'I': 1.83, 'K': -1.54, 'L': 1.8,
        'M': 1.1, 'N': -0.99, 'P': 0.84, 'Q': -0.93, 'R': -1.5,
        'S': -0.63, 'T': -0.27, 'V': 1.32, 'W': 1.35, 'Y': 0.39
    },
    'size': {
        'A': 2.5, 'C': 3, 'D': 2.5, 'E': 5, 'F': 6.5,
        'G': 0.5, 'H': 6, 'I': 5.5, 'K': 7, 'L': 5.5,
        'M': 6, 'N': 5, 'P': 5.5, 'Q': 6, 'R': 7.5,
        'S': 3, 'T': 5, 'V': 5, 'W': 7, 'Y': 7
    },
    'consensus_normalized_hydrophobicity': {
        'A': 0.62, 'C': 0.29, 'D': -0.9, 'E': -0.74, 'F': 1.19,
        'G': 0.48, 'H': -0.4, 'I': 1.38, 'K': -1.5, 'L': 1.06,
        'M': 0.64, 'N': -0.78, 'P': 0.12, 'Q': -0.85, 'R': -2.53,
        'S': -0.18, 'T': -0.05, 'V': 1.08, 'W': 0.81, 'Y': 0.26
    },
    'hydrophobicity_helix_membrane': {
        'A': -1.6, 'C': -2, 'D': -2.1, 'E': -2.6, 'F': -3.7,
        'G': -1, 'H': -3, 'I': -3.1, 'K': -3.7, 'L': -2.8,
        'M': -3.4, 'N': -2.2, 'P': -1.8, 'Q': -2.9, 'R': -4.4,
        'S': -1.6, 'T': -2.2, 'V': -2.6, 'W': -4.9, 'Y': -3.7
    },
    'molecular_weight': {
        'A': 89.09, 'C': 121.15, 'D': 133.1, 'E': 147.13, 'F': 165.19,
        'G': 75.07, 'H': 155.16, 'I': 131.17, 'K': 146.19, 'L': 131.17,
        'M': 149.21, 'N': 132.12, 'P': 115.13, 'Q': 146.15, 'R': 174.2,
        'S': 105.09, 'T': 119.12, 'V': 117.15, 'W': 204.24, 'Y': 181.19
    },
    'hydrophobic_parameter': {
        'A': 0.31, 'C': 1.54, 'D': -0.77, 'E': -0.64, 'F': 1.79,
        'G': 0, 'H': 0.13, 'I': 1.8, 'K': -0.99, 'L': 1.7,
        'M': 1.23, 'N': -0.6, 'P': 0.72, 'Q': -0.22, 'R': -1.01,
        'S': -0.04, 'T': 0.26, 'V': 1.22, 'W': 2.25, 'Y': 0.96
    },
    'vdw_volume': {
        'A': 1, 'C': 2.43, 'D': 2.78, 'E': 3.78, 'F': 5.89,
        'G': 0, 'H': 4.66, 'I': 4, 'K': 4.77, 'L': 4,
        'M': 4.43, 'N': 2.95, 'P': 2.72, 'Q': 3.95, 'R': 6.13,
        'S': 1.6, 'T': 2.6, 'V': 3, 'W': 8.08, 'Y': 6.47
    },
    'polarity': {
        'A': 8.1, 'C': 5.5, 'D': 13, 'E': 12.3, 'F': 5.2,
        'G': 9, 'H': 10.4, 'I': 5.2, 'K': 11.3, 'L': 4.9,
        'M': 5.7, 'N': 11.6, 'P': 8, 'Q': 10.5, 'R': 10.5,
        'S': 9.2, 'T': 8.6, 'V': 5.9, 'W': 5.4, 'Y': 6.2
    },
    'volume': {
        'A': 31, 'C': 55, 'D': 54, 'E': 83, 'F': 132,
        'G': 3, 'H': 96, 'I': 111, 'K': 119, 'L': 111,
        'M': 105, 'N': 56, 'P': 32.5, 'Q': 85, 'R': 124,
        'S': 32, 'T': 61, 'V': 84, 'W': 170, 'Y': 136
    },
    'compressibility': {
        'A': -25.5, 'C': -32.82, 'D': -33.12, 'E': -36.17, 'F': -34.54,
        'G': -27, 'H': -31.84, 'I': -31.78, 'K': -32.4, 'L': -31.78,
        'M': -31.18, 'N': -30.9, 'P': -23.25, 'Q': -32.6, 'R': -26.62,
        'S': -29.88, 'T': -31.23, 'V': -30.62, 'W': -30.24, 'Y': -35.01
    },
    'avg_long_range_contact_energy': {
        'A': 3.92, 'C': 5.55, 'D': 2.85, 'E': 2.72, 'F': 4.53,
        'G': 4.31, 'H': 3.77, 'I': 5.58, 'K': 2.79, 'L': 4.59,
        'M': 4.14, 'N': 3.64, 'P': 3.57, 'Q': 3.06, 'R': 3.78,
        'S': 3.75, 'T': 4.09, 'V': 5.43, 'W': 4.83, 'Y': 4.93
    },
    'avg_medium_range_contact_energy': {
        'A': 2.11, 'C': 1.88, 'D': 1.8, 'E': 2.09, 'F': 1.98,
        'G': 1.53, 'H': 1.98, 'I': 1.77, 'K': 1.96, 'L': 2.19,
        'M': 2.27, 'N': 1.84, 'P': 1.32, 'Q': 2.03, 'R': 1.94,
        'S': 1.57, 'T': 1.57, 'V': 1.63, 'W': 1.9, 'Y': 1.67
    },
    'long_range_non_bounded_energy': {
        'A': 0.49, 'C': 0.67, 'D': 0.35, 'E': 0.37, 'F': 0.72,
        'G': 0.53, 'H': 0.54, 'I': 0.76, 'K': 0.3, 'L': 0.65,
        'M': 0.65, 'N': 0.38, 'P': 0.46, 'Q': 0.4, 'R': 0.55,
        'S': 0.45, 'T': 0.52, 'V': 0.73, 'W': 0.83, 'Y': 0.65
    },
    'mean_rms_fluctuational_displacement': {
        'A': 0.96, 'C': 0.87, 'D': 1.14, 'E': 1.07, 'F': 0.69,
        'G': 1.16, 'H': 0.8, 'I': 0.76, 'K': 1.14, 'L': 0.79,
        'M': 0.78, 'N': 1.04, 'P': 1.16, 'Q': 1.07, 'R': 1.05,
        'S': 1.13, 'T': 0.96, 'V': 0.79, 'W': 0.77, 'Y': 1.01
    },
    'refractive_index': {
        'A': 14.34, 'C': 35.77, 'D': 12, 'E': 17.26, 'F': 29.4,
        'G': 0, 'H': 21.81, 'I': 19.06, 'K': 21.29, 'L': 18.78,
        'M': 21.64, 'N': 13.28, 'P': 10.93, 'Q': 17.56, 'R': 26.66,
        'S': 6.35, 'T': 11.01, 'V': 13.92, 'W': 42.53, 'Y': 31.55
    },
    'solvent_accessible_reduction': {
        'A': 3.7, 'C': 3.03, 'D': 2.6, 'E': 3.3, 'F': 6.6,
        'G': 3.13, 'H': 3.57, 'I': 7.69, 'K': 1.79, 'L': 5.88,
        'M': 5.21, 'N': 2.12, 'P': 2.12, 'Q': 2.7, 'R': 2.53,
        'S': 2.43, 'T': 2.6, 'V': 7.14, 'W': 6.25, 'Y': 3.03
    },
    'total_non_bounded_energy': {
        'A': 1.9, 'C': 2.04, 'D': 1.52, 'E': 1.54, 'F': 1.86,
        'G': 1.9, 'H': 1.76, 'I': 1.95, 'K': 1.37, 'L': 1.97,
        'M': 1.96, 'N': 1.56, 'P': 1.7, 'Q': 1.52, 'R': 1.48,
        'S': 1.75, 'T': 1.77, 'V': 1.98, 'W': 1.87, 'Y': 1.69
    },
    'unfolding_entropy_change_hydration': {
        'A': 1.7, 'C': 1.79, 'D': 1.57, 'E': 1.92, 'F': 4.05,
        'G': 0.87, 'H': 3.45, 'I': 4.16, 'K': 2.83, 'L': 3.79,
        'M': 3.56, 'N': 2.13, 'P': 2.27, 'Q': 2.31, 'R': 4.47,
        'S': 2.12, 'T': 2.42, 'V': 3.28, 'W': 5.19, 'Y': 5.03
    },
    'unfolding_hydration_heat_capacity_change': {
        'A': 14.22, 'C': 9.41, 'D': 2.73, 'E': 3.17, 'F': 39.06,
        'G': 4.88, 'H': 20.05, 'I': 41.98, 'K': 17.68, 'L': 38.26,
        'M': 31.67, 'N': 3.91, 'P': 23.69, 'Q': 3.74, 'R': 16.66,
        'S': 6.14, 'T': 16.11, 'V': 32.58, 'W': 37.69, 'Y': 30.54
    },
    'retention_coefficient_ph7': {
        'A': 2.2, 'C': 2.6, 'D': -2.6, 'E': -1.3, 'F': 9,
        'G': -0.2, 'H': 2.2, 'I': 8.3, 'K': -0.2, 'L': 9,
        'M': 6, 'N': -0.8, 'P': 2.2, 'Q': 0, 'R': 0.9,
        'S': -0.5, 'T': 0.3, 'V': 5.7, 'W': 9.5, 'Y': 4.6
    },
    'amino_acid_partition_energy': {
        'A': 0.1, 'C': -1.42, 'D': 0.78, 'E': 0.83, 'F': -2.12,
        'G': 0.33, 'H': -0.5, 'I': -1.13, 'K': 1.4, 'L': -1.18,
        'M': -1.59, 'N': 0.48, 'P': 0.73, 'Q': 0.95, 'R': 1.91,
        'S': 0.52, 'T': 0.07, 'V': -1.27, 'W': -0.51, 'Y': -0.21
    },
    'pka_cooh': {
        'A': 2.33, 'C': 1.91, 'D': 1.95, 'E': 2.16, 'F': 2.18,
        'G': 2.34, 'H': 1.7, 'I': 2.26, 'K': 2.15, 'L': 2.32,
        'M': 2.16, 'N': 2.16, 'P': 1.95, 'Q': 2.18, 'R': 2.03,
        'S': 2.13, 'T': 2.2, 'V': 2.27, 'W': 2.38, 'Y': 2.24
    },
    'hydrophilicity': {
        'A': -0.5, 'C': -1, 'D': 3, 'E': 3, 'F': -2.5,
        'G': 0, 'H': -0.5, 'I': -1.8, 'K': 3, 'L': -1.8,
        'M': -1.3, 'N': 0.2, 'P': 0, 'Q': 0.2, 'R': 3,
        'S': 0.3, 'T': -0.4, 'V': -1.5, 'W': -3.4, 'Y': -2.3
    },
}


def extract(sequences):
    """extract physicochemical features for a list of peptide sequences.
    for each of the 28 properties, computes 5 statistics (mean, std,
min, max, sum)
    plus sequence length = 141 total features."""
    all_features = []
    for seq in sequences:
        feats = {}
        # compute summary stats for each of the 28 physicochemical properties
        for prop_name, prop_dict in AA_PROPERTIES.items():
            values = [prop_dict.get(aa, 0) for aa in seq]
            if len(values) == 0:
                values = [0]
            feats[f'{prop_name}_mean'] = np.mean(values)
            feats[f'{prop_name}_std'] = np.std(values)
            feats[f'{prop_name}_min'] = np.min(values)
            feats[f'{prop_name}_max'] = np.max(values)
            feats[f'{prop_name}_sum'] = np.sum(values)
        # add sequence length as a standalone feature
        feats['seq_length'] = len(seq)
        all_features.append(feats)
    df = pd.DataFrame(all_features)
    print(f"  Physicochemical features: {df.shape[1]} features extracted "
          f"(28 properties x 5 stats + seq_length)")
    return df