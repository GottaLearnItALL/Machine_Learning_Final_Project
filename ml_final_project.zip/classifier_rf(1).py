"""
Random Forest classifier for peptide toxicity prediction.

Random Forest builds an ensemble of decision trees, each trained on
a random subset of data and features. Final prediction is by majority vote.
Generally one of the strongest out-of-the-box classifiers.
"""

from sklearn.ensemble import RandomForestClassifier
from config import RANDOM_STATE


NAME = "Random_Forest"


def get_model():
    """Return a configured Random Forest classifier."""
    return RandomForestClassifier(
        n_estimators=100,
        max_depth=None,
        min_samples_split=2,
        random_state=RANDOM_STATE,
        n_jobs=-1
    )
