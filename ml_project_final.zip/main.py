import warnings
import numpy as np
import pandas as pd
import torch
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier

# --- Our modules ---
import config
from parse_fasta import load_data
import features_physicochemical
import features_sequence
import features_plm

# Classifiers (each in its own file)
import classifier_knn
import classifier_svm
import classifier_nb
import classifier_ann
import classifier_rf
import classifier_bagging

# Neural network models
import model_cnn
import model_fusion

# Evaluation and visualization
from evaluation import evaluate_classifier, run_shap_analysis
import visualize

warnings.filterwarnings('ignore')
np.random.seed(config.RANDOM_STATE)
torch.manual_seed(config.RANDOM_STATE)


def align_columns(train_df, test_df):
    """Make sure train and test DataFrames have the same columns."""
    for col in train_df.columns:
        if col not in test_df.columns:
            test_df[col] = 0
    for col in test_df.columns:
        if col not in train_df.columns:
            train_df[col] = 0
    test_df = test_df[train_df.columns]
    return train_df, test_df


def main():
    print("=" * 70)
    print("  PEPTIDE TOXICITY PREDICTION PIPELINE")
    print("=" * 70)

    # Check CUDA
    if torch.cuda.is_available():
        print(f"  CUDA available: {torch.cuda.get_device_name(0)}")
    else:
        print("  CUDA not available — using CPU")


    # STEP 1: Load Data
 
    print("\n[STEP 1] Loading data...")
    train_df, test_df = load_data(config.TRAIN_FILE, config.TEST_FILE)

    print(f"\n  Training: {len(train_df)} samples | "
          f"Test: {len(test_df)} samples")
    print(f"  Train labels: {dict(train_df['label'].value_counts())}")
    print(f"  Test labels:  {dict(test_df['label'].value_counts())}")

    train_seqs = train_df['sequence'].tolist()
    test_seqs = test_df['sequence'].tolist()
    y_train = train_df['label'].values
    y_test = test_df['label'].values

    
    # STEP 2: Feature Extraction

    print("\n[STEP 2] Extracting features...")

    # 2.1 Physicochemical
    print("\n  --- Physicochemical ---")
    physchem_train = features_physicochemical.extract(train_seqs)
    physchem_test = features_physicochemical.extract(test_seqs)

    # 2.2 Sequence-based
    print("\n  --- Sequence-Based ---")
    seq_train = features_sequence.extract(train_seqs)
    seq_test = features_sequence.extract(test_seqs)
    seq_train, seq_test = align_columns(seq_train, seq_test)

    # 2.3 PLM Embeddings
    print("\n  --- PLM Embeddings ---")
    plm_train = features_plm.extract(train_seqs)
    plm_test = features_plm.extract(test_seqs)
    plm_train, plm_test = align_columns(plm_train, plm_test)

    # Build feature dict
    feature_sets = {
        'Physicochemical': (physchem_train, physchem_test),
        'Sequence_Based': (seq_train, seq_test),
        'PLM': (plm_train, plm_test),
    }

    # Combined (all 3 concatenated)
    combined_train = pd.concat([physchem_train, seq_train, plm_train], axis=1)
    combined_test = pd.concat([physchem_test, seq_test, plm_test], axis=1)
    feature_sets['Combined'] = (combined_train, combined_test)

    # STEP 3: Traditional ML Classifiers
    print("\n[STEP 3] Training traditional ML classifiers")
    all_results = []

    # List of classifier modules
    classifiers = [
        classifier_knn,
        classifier_svm,
        classifier_nb,
        classifier_ann,
        classifier_rf,
        classifier_bagging,
    ]

    for feat_name, (ft_train, ft_test) in feature_sets.items():
        print(f"\n  === Feature Group: {feat_name} "
              f"({ft_train.shape[1]} features) ===")

        scaler = StandardScaler() # We Normalize the data to scale evenly for all features
        X_tr = scaler.fit_transform(ft_train.values)
        X_te = scaler.transform(ft_test.values)

        for clf_module in classifiers:
            clf = clf_module.get_model()
            result = evaluate_classifier(
                clf, X_tr, y_train, X_te, y_test,
                clf_module.NAME, feat_name
            )
            all_results.append(result)

    # STEP 4: CNN (Deep Learning)
  
    print("\n[STEP 4] Training CNN...")

    for feat_name, (ft_train, ft_test) in feature_sets.items():
        print(f"\n  CNN on {feat_name} ({ft_train.shape[1]} features)...")

        scaler = StandardScaler()
        X_tr = scaler.fit_transform(ft_train.values)
        X_te = scaler.transform(ft_test.values)

        result, _ = model_cnn.train_and_evaluate(
            X_tr, y_train, X_te, y_test, feat_name
        )
        all_results.append(result)

    # STEP 5: Multi-View Attention Fusion (Bonus)
  
    print("\n[STEP 5] Training Multi-View Attention Fusion...")

    # Scale each view separately
    views_train_scaled = []
    views_test_scaled = []
    for key in ['Physicochemical', 'Sequence_Based', 'PLM']:
        ft_train, ft_test = feature_sets[key]
        sc = StandardScaler()
        views_train_scaled.append(sc.fit_transform(ft_train.values))
        views_test_scaled.append(sc.transform(ft_test.values))

    fusion_result, fusion_model, attn_weights = model_fusion.train_and_evaluate(
        views_train_scaled, views_test_scaled, y_train, y_test
    )
    all_results.append(fusion_result)


    # STEP 6: Results Summary

    print("\n[STEP 6] Results Summary")
    print("=" * 70)

    results_df = pd.DataFrame(all_results)
    print(results_df.to_string(index=False))

    # Save to CSV
    csv_path = f"{config.OUTPUT_DIR}/all_results.csv"
    results_df.to_csv(csv_path, index=False)
    print(f"\n  Saved: {csv_path}")

    # STEP 7: Visualizations
 
    print("\n[STEP 7] Generating plots...")
    visualize.generate_all_plots(results_df, attn_weights)

    # STEP 8: SHAP Analysis For more Analysis

    print("\n[STEP 8] SHAP Interpretability...")

    # Run on Random Forest + Combined features
    shap_scaler = StandardScaler()
    X_tr_comb = shap_scaler.fit_transform(combined_train.values)
    X_te_comb = shap_scaler.transform(combined_test.values)

    rf = RandomForestClassifier(n_estimators=100, random_state=config.RANDOM_STATE)
    rf.fit(X_tr_comb, y_train)
    run_shap_analysis(
        rf, X_tr_comb, X_te_comb,
        combined_train.columns.tolist(),
        'RandomForest', 'Combined', config.OUTPUT_DIR
    )


    print("\n" + "=" * 10)
    print("  PIPELINE COMPLETE!")
    print(f"\n  All outputs saved to: {config.OUTPUT_DIR}/")

    # Best result
    numeric = results_df.copy()
    numeric['Test_MCC'] = pd.to_numeric(numeric['Test_MCC'], errors='coerce')
    best = numeric.loc[numeric['Test_MCC'].idxmax()]
    print(f"\n  BEST RESULT:")
    print(f"    Classifier:    {best['Classifier']}")
    print(f"    Feature Group: {best['Feature_Group']}")
    print(f"    Accuracy:      {best['Test_Accuracy']}")
    print(f"    MCC:           {best['Test_MCC']}")


if __name__ == '__main__':
    main()
