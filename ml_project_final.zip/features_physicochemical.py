"""
Physicochemical feature extraction for peptide sequences.

Extracts features based on known physical and chemical properties
of the 20 standard amino acids. For each property, we compute
summary statistics (mean, std, min, max, sum) across the sequence.

Sources: AAindex database, Ferdous et al. 2024, Muhammod et al. 2019
"""

import numpy as np
import pandas as pd


# ---- Amino Acid Property Lookup Tables ----

AA_PROPERTIES = {
    # Hydrophobicity (Kyte-Doolittle scale)
    'hydrophobicity': {
        'A': 1.8, 'R': -4.5, 'N': -3.5, 'D': -3.5, 'C': 2.5,
        'E': -3.5, 'Q': -3.5, 'G': -0.4, 'H': -3.2, 'I': 4.5,
        'L': 3.8, 'K': -3.9, 'M': 1.9, 'F': 2.8, 'P': -1.6,
        'S': -0.8, 'T': -0.7, 'W': -0.9, 'Y': -1.3, 'V': 4.2
    },
    # Molecular weight (Daltons)
    'molecular_weight': {
        'A': 89.09, 'R': 174.20, 'N': 132.12, 'D': 133.10, 'C': 121.16,
        'E': 147.13, 'Q': 146.15, 'G': 75.03, 'H': 155.16, 'I': 131.17,
        'L': 131.17, 'K': 146.19, 'M': 149.21, 'F': 165.19, 'P': 115.13,
        'S': 105.09, 'T': 119.12, 'W': 204.23, 'Y': 181.19, 'V': 117.15
    },
    # Net charge at pH 7
    'charge': {
        'A': 0, 'R': 1, 'N': 0, 'D': -1, 'C': 0,
        'E': -1, 'Q': 0, 'G': 0, 'H': 0.1, 'I': 0,
        'L': 0, 'K': 1, 'M': 0, 'F': 0, 'P': 0,
        'S': 0, 'T': 0, 'W': 0, 'Y': 0, 'V': 0
    },
    # Polarity (Grantham, 1974)
    'polarity': {
        'A': 8.1, 'R': 10.5, 'N': 11.6, 'D': 13.0, 'C': 5.5,
        'E': 12.3, 'Q': 10.5, 'G': 9.0, 'H': 10.4, 'I': 5.2,
        'L': 4.9, 'K': 11.3, 'M': 5.7, 'F': 5.2, 'P': 8.0,
        'S': 9.2, 'T': 8.6, 'W': 5.4, 'Y': 6.2, 'V': 5.9
    },
    # Van der Waals volume
    'vdw_volume': {
        'A': 67.0, 'R': 148.0, 'N': 96.0, 'D': 91.0, 'C': 86.0,
        'E': 109.0, 'Q': 114.0, 'G': 48.0, 'H': 118.0, 'I': 124.0,
        'L': 124.0, 'K': 135.0, 'M': 124.0, 'F': 135.0, 'P': 90.0,
        'S': 73.0, 'T': 93.0, 'W': 163.0, 'Y': 141.0, 'V': 105.0
    },
    # Isoelectric point (pI)
    'pI': {
        'A': 6.11, 'R': 10.76, 'N': 10.76, 'D': 2.98, 'C': 5.02,
        'E': 3.08, 'Q': 5.65, 'G': 6.06, 'H': 7.64, 'I': 6.04,
        'L': 6.04, 'K': 9.47, 'M': 5.74, 'F': 5.91, 'P': 6.30,
        'S': 5.68, 'T': 5.60, 'W': 5.88, 'Y': 5.63, 'V': 6.02
    }
}


def extract(sequences):
    """
    Extract physicochemical features for a list of peptide sequences.

    For each of the 6 properties, computes 5 statistics (mean, std, min, max, sum)
    plus sequence length = 31 total features.

    Args:
        sequences: list of peptide strings

    Returns:
        pd.DataFrame with 31 feature columns
    """
    all_features = []

    for seq in sequences:
        feats = {}
        for prop_name, prop_dict in AA_PROPERTIES.items():
            values = [prop_dict.get(aa, 0) for aa in seq]
            if len(values) == 0:
                values = [0]
            feats[f'{prop_name}_mean'] = np.mean(values)
            feats[f'{prop_name}_std'] = np.std(values)
            feats[f'{prop_name}_min'] = np.min(values)
            feats[f'{prop_name}_max'] = np.max(values)
            feats[f'{prop_name}_sum'] = np.sum(values)

        feats['seq_length'] = len(seq)
        all_features.append(feats)

    df = pd.DataFrame(all_features)
    print(f"  Physicochemical features: {df.shape[1]} features extracted")
    return df
